$background = 'white'; // По умолчанию белый фон

if (isset($_COOKIE['background'])) {
    $background = $_COOKIE['background'];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $background = $_POST['background'];
    setcookie('background', $background, time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <select name="background">
            <option value="white" ' . ($background == 'white' ? 'selected' : '') . '>Белый</option>
            <option value="blue" ' . ($background == 'blue' ? 'selected' : '') . '>Синий</option>
            <option value="green" ' . ($background == 'green' ? 'selected' : '') . '>Зеленый</option>
            <option value="url(image.jpg)" ' . ($background == 'url(image.jpg)' ? 'selected' : '') . '>Изображение</option>
        </select>
        <input type="submit">
      </form>';

echo '<style>body { background-color: ' . $background . '; }</style>';