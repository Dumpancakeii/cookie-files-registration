if (isset($_COOKIE['scroll_position'])) {
    $scrollPosition = $_COOKIE['scroll_position'];
} else {
    $scrollPosition = 0; // Начальная позиция
}

echo '<script>
        window.onload = function() {
            window.scrollTo(0, ' . $scrollPosition . ');
        }

        window.onbeforeunload = function() {
            document.cookie = "scroll_position=" + window.scrollY + "; path=/; max-age=3600"; // Сохраняем позицию при уходе
        }
      </script>';