if (isset($_COOKIE['age'])) {
    echo "Ваш возраст: " . $_COOKIE['age'];
} else {
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['age'])) {
        setcookie('age', $_POST['age'], time() + (86400 * 30)); // 30 дней
        echo "Ваш возраст: " . $_POST['age'];
    } else {
        echo '<form method="POST">
                <input type="number" name="age" placeholder="Ваш возраст" required>
                <input type="submit" value="Отправить">
              </form>';
    }
}