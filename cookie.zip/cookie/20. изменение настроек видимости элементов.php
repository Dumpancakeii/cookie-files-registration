$visibility = isset($_COOKIE['visibility']) ? $_COOKIE['visibility'] : 'visible';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $visibility = $_POST['visibility'];
    setcookie('visibility', $visibility, time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <select name="visibility">
            <option value="visible" ' . ($visibility == 'visible' ? 'selected' : '') . '>Показать</option>
            <option value="hidden" ' . ($visibility == 'hidden' ? 'selected' : '') . '>Скрыть</option>
        </select>
        <input type="submit" value="Применить">
      </form>';

echo '<div style="display: ' . ($visibility == 'visible' ? 'block' : 'none') . ';">
        Эта часть контента может быть скрыта или показана.
      </div>';