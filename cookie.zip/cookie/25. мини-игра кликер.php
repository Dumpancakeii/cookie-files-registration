$score = 0;

if (isset($_COOKIE['score'])) {
    $score = $_COOKIE['score'];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $score++;
    setcookie('score', $score, time() + (86400 * 30));
}

echo '<form method="POST">
        <button type="submit">Кликни меня!</button>
      </form>';
echo "Ваш счёт: " . $score;