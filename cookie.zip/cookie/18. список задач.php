$tasks = isset($_COOKIE['tasks']) ? json_decode($_COOKIE['tasks'], true) : [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['task'])) {
    $tasks[] = $_POST['task'];
    setcookie('tasks', json_encode($tasks), time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <input type="text" name="task" placeholder="Введите задачу" required>
        <input type="submit" value="Добавить">
      </form>';

echo '<ul>';
foreach ($tasks as $task) {
    echo '<li>' . htmlspecialchars($task) . '</li>';
}
echo '</ul>';