if (isset($_COOKIE['visits'])) {
    $visits = ++$_COOKIE['visits'];
} else {
    $visits = 1;
}
setcookie('visits', $visits, time() + (86400 * 30));
echo "Количество посещений: " . $visits;