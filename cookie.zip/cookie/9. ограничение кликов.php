$clicks = 0;
$limit = 10;

if (isset($_COOKIE['clicks'])) {
    $clicks = $_COOKIE['clicks'];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $clicks < $limit) {
    $clicks++;
    setcookie('clicks', $clicks, time() + (86400 * 30));
}

echo '<form method="POST">
        <button type="submit" ' . ($clicks >= $limit ? 'disabled' : '') . '>Нажми меня!</button>
      </form>';
echo "Количество кликов: " . $clicks;
if ($clicks >= $limit) {
    echo " Достигнут лимит кликов!";
}