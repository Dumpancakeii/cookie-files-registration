$size = 'medium'; // По умолчанию средний размер текста

if (isset($_COOKIE['text_size'])) {
    $size = $_COOKIE['text_size'];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $size = $_POST['size'];
    setcookie('text_size', $size, time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <select name="size">
            <option value="small" ' . ($size == 'small' ? 'selected' : '') . '>Мелкий</option>
            <option value="medium" ' . ($size == 'medium' ? 'selected' : '') . '>Средний</option>
            <option value="large" ' . ($size == 'large' ? 'selected' : '') . '>Крупный</option>
        </select>
        <input type="submit">
      </form>';

echo '<div style="font-size:' . ($size == 'small' ? '12px' : ($size == 'large' ? '24px' : '16px')) . ';">
        Пример текста с размером: ' . $size . '
      </div>';