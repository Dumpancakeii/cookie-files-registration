$greetings = ["Привет!", "Добро пожаловать!", "Здравствуйте!", "Хорошего дня!"];

if (!isset($_COOKIE['greeted'])) {
    $randomGreeting = $greetings[array_rand($greetings)];
    setcookie('greeted', 'yes', time() + (86400 * 30)); // Установим cookie
    echo $randomGreeting;
} else {
    echo "Рады вас видеть снова!";
}