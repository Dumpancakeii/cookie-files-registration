session_start();

if (!isset($_SESSION['start_time'])) {
    $_SESSION['start_time'] = time();
}

if (isset($_COOKIE['total_time'])) {
    $totalTime = $_COOKIE['total_time'] + (time() - $_SESSION['start_time']);
} else {
    $totalTime = time() - $_SESSION['start_time'];
}
setcookie('total_time', $totalTime, time() + (86400 * 30)); // Сохраняем общее время

echo "Время, проведенное на сайте: " . gmdate("H:i:s", $totalTime);