$step = isset($_COOKIE['step']) ? $_COOKIE['step'] : 1;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $step++;
    setcookie('step', $step, time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

if ($step > 3) {
    echo "Спасибо за участие!";
    setcookie('step', '', time() - 3600); // Удаляем cookie
    exit();
}

echo '<form method="POST">';
switch ($step) {
    case 1: echo 'Шаг 1: Ваше имя: <input name="name" required><br>'; break;
    case 2: echo 'Шаг 2: Ваш email: <input name="email" required><br>'; break;
    case 3: echo 'Шаг 3: Ваш возраст: <input name="age" type="number" required><br>'; break;
}
echo '<input type="submit" value="Далее">
      </form>';