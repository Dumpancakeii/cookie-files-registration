if (!isset($_COOKIE['banner_closed'])) {
    echo '<div id="banner">
            Рекламный баннер <button onclick="closeBanner()">Закрыть</button>
          </div>';
}

echo '<script>
        function closeBanner() {
            document.cookie = "banner_closed=1; path=/; max-age=3600"; // 1 час
            document.getElementById("banner").style.display = "none";
        }
      </script>';