session_start();

if (!isset($_SESSION['first_visit'])) {
    $_SESSION['first_visit'] = time();
}

$timeLimit = 3600; // 1 час

if (time() - $_SESSION['first_visit'] > $timeLimit) {
    echo "Вы превысили лимит времени на сайте.";
} else {
    echo "Время на сайте: " . gmdate("H:i:s", time() - $_SESSION['first_visit']);
}