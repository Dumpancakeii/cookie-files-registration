if (isset($_COOKIE['name'])) {
    echo "Привет, " . $_COOKIE['name'] . "!";
} else {
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['name'])) {
        setcookie('name', $_POST['name'], time() + (86400 * 30)); // 30 дней
        echo "Привет, " . $_POST['name'] . "!";
    } else {
        echo '<form method="POST"><input name="name" placeholder="Введите ваше имя"><input type="submit"></form>';
    }
}