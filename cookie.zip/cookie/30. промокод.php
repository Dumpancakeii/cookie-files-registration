$promoUsed = isset($_COOKIE['promo_used']) ? $_COOKIE['promo_used'] : 'no';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['promo_code'] == 'DISCOUNT2023' && $promoUsed == 'no') {
    setcookie('promo_used', 'yes', time() + (86400 * 30)); // Установить факт использования
    echo "Промокод активирован!";
} elseif ($promoUsed == 'yes') {
    echo "Вы уже использовали промокод.";
} else {
    echo '<form method="POST">
            <input type="text" name="promo_code" placeholder="Введите промокод">
            <input type="submit" value="Активировать">
          </form>';
}