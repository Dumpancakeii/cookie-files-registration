$cart = isset($_COOKIE['cart']) ? json_decode($_COOKIE['cart'], true) : [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['product'])) {
    $cart[] = $_POST['product'];
    setcookie('cart', json_encode($cart), time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <input type="text" name="product" placeholder="Название товара" required>
        <input type="submit" value="Добавить в корзину">
      </form>';

echo '<h2>Корзина:</h2>';
echo '<ul>';
foreach ($cart as $product) {
    echo '<li>' . htmlspecialchars($product) . '</li>';
}
echo '</ul>';