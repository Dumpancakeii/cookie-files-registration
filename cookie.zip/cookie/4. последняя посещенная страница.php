if (isset($_COOKIE['last_page'])) {
    header("Location: " . $_COOKIE['last_page']);
    exit();
} else {
    setcookie('last_page', $_SERVER['REQUEST_URI'], time() + (86400 * 30));
}