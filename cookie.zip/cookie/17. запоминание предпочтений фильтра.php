$filter = isset($_COOKIE['filter']) ? $_COOKIE['filter'] : 'all';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $filter = $_POST['filter'];
    setcookie('filter', $filter, time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <select name="filter">
            <option value="all" ' . ($filter == 'all' ? 'selected' : '') . '>Все товары</option>
            <option value="electronics" ' . ($filter == 'electronics' ? 'selected' : '') . '>Электроника</option>
            <option value="clothing" ' . ($filter == 'clothing' ? 'selected' : '') . '>Одежда</option>
        </select>
        <input type="submit" value="Применить">
      </form>';
echo "Текущий фильтр: " . $filter;