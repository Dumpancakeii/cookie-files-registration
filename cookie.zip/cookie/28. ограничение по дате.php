$dateCheck = '2023-10-01'; // Укажите дату для проверки

if (!isset($_COOKIE['visited_' . $dateCheck])) {
    setcookie('visited_' . $dateCheck, 'yes', strtotime($dateCheck) + (86400 * 30)); // Установим cookie до конца дня
    echo "Вы посетили сайт впервые в этот день!";
} else {
    echo "Вы уже посещали сайт " . $dateCheck;
}