if (!isset($_COOKIE['visited'])) {
    setcookie('visited', 'yes', time() + (86400 * 30));
    echo "Вы новый посетитель!";
} else {
    echo "Вы уже посещали этот сайт.";
}