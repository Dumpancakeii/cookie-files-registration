$volume = 50; // По умолчанию 50%

if (isset($_COOKIE['volume'])) {
    $volume = $_COOKIE['volume'];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $volume = $_POST['volume'];
    setcookie('volume', $volume, time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <input type="range" name="volume" min="0" max="100" value="' . $volume . '">
        <input type="submit">
      </form>';
echo "Уровень звука: " . $volume . "%";