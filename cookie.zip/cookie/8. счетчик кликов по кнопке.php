$clicks = 0;

if (isset($_COOKIE['clicks'])) {
    $clicks = $_COOKIE['clicks'];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $clicks++;
    setcookie('clicks', $clicks, time() + (86400 * 30));
}

echo '<form method="POST">
        <button type="submit">Нажми меня!</button>
      </form>';
echo "Количество кликов: " . $clicks;