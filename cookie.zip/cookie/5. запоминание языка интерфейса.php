if (isset($_COOKIE['language'])) {
    $language = $_COOKIE['language'];
} else {
    $language = 'ru'; // По умолчанию русский
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['language'])) {
    setcookie('language', $_POST['language'], time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <select name="language">
            <option value="ru">Русский</option>
            <option value="en">Английский</option>
        </select>
        <input type="submit">
      </form>';