$testMode = isset($_COOKIE['test_mode']) ? $_COOKIE['test_mode'] : 'off';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $testMode = $_POST['mode'];
    setcookie('test_mode', $testMode, time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <select name="mode">
            <option value="off" ' . ($testMode == 'off' ? 'selected' : '') . '>Отключить тестовый режим</option>
            <option value="on" ' . ($testMode == 'on' ? 'selected' : '') . '>Включить тестовый режим</option>
        </select>
        <input type="submit" value="Применить">
      </form>';

if ($testMode == 'on') {
    echo '<div>Сайт в тестовом режиме!</div>';
}