if (isset($_COOKIE['notification_closed'])) {
    // Уведомление закрыто, ничего не показываем
} else {
    echo '<div id="notification">
            Уведомление! <button onclick="closeNotification()">Закрыть</button>
          </div>';
}

echo '<script>
        function closeNotification() {
            document.cookie = "notification_closed=1; path=/; max-age=3600"; // 1 час
            document.getElementById("notification").style.display = "none";
        }
      </script>';