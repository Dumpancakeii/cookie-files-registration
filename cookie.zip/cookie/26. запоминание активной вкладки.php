$activeTab = isset($_COOKIE['active_tab']) ? $_COOKIE['active_tab'] : 'tab1';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $activeTab = $_POST['tab'];
    setcookie('active_tab', $activeTab, time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <button name="tab" value="tab1" ' . ($activeTab == 'tab1' ? 'style="font-weight:bold;"' : '') . '>Вкладка 1</button>
        <button name="tab" value="tab2" ' . ($activeTab == 'tab2' ? 'style="font-weight:bold;"' : '') . '>Вкладка 2</button>
      </form>';

if ($activeTab == 'tab1') {
    echo '<div>Содержимое вкладки 1</div>';
} else {
    echo '<div>Содержимое вкладки 2</div>';
}