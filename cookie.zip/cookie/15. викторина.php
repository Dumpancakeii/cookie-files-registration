$questions = [
    1 => "Какой язык программирования используется для веб-разработки?",
    2 => "Какой тег используется для создания гиперссылки?",
    3 => "Что такое PHP?"
];

if (!isset($_COOKIE['answered'])) {
    $answered = [];
} else {
    $answered = json_decode($_COOKIE['answered'], true);
}

foreach ($questions as $key => $question) {
    if (!in_array($key, $answered)) {
        echo "Вопрос " . $key . ": " . $question . "<br>";
        $answered[] = $key;
        setcookie('answered', json_encode($answered), time() + (86400 * 30));
        break;
    }
}

if (count($answered) === count($questions)) {
    echo "Вы ответили на все вопросы!";
}