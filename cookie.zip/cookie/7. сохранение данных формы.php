$name = $email = '';

if (isset($_COOKIE['name'])) {
    $name = $_COOKIE['name'];
}
if (isset($_COOKIE['email'])) {
    $email = $_COOKIE['email'];
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    setcookie('name', $name, time() + (86400 * 30));
    setcookie('email', $email, time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <input name="name" placeholder="Ваше имя" value="' . htmlspecialchars($name) . '">
        <input name="email" type="email" placeholder="Ваш email" value="' . htmlspecialchars($email) . '">
        <input type="submit">
      </form>';