if (isset($_COOKIE['theme'])) {
    echo '<link rel="stylesheet" type="text/css" href="' . $_COOKIE['theme'] . '.css">';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['theme'])) {
    setcookie('theme', $_POST['theme'], time() + (86400 * 30));
    header("Location: " . $_SERVER['PHP_SELF']);
}

echo '<form method="POST">
        <select name="theme">
            <option value="light">Светлая</option>
            <option value="dark">Тёмная</option>
        </select>
        <input type="submit">
      </form>';